package com.example.mystore.contants;

public class Urls {
    public static final String BASE="https://vpd121.itstep.click";
}
